package es.unican.is2;

public @interface Test {

}
