package es.unican.is2.seguroscommon;

import java.time.LocalDate;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SuppressWarnings("unused")
public class ClienteTest {
    
    @Test 
    public void testTotalSeguros() {
        Cliente cliente = new Cliente();
        Seguro seguro1 = new Seguro();
        seguro1.setId(1);
        seguro1.setMatricula("1234ABC");
        seguro1.setPotencia(100);
        seguro1.setCobertura(Cobertura.TERCEROS);
        seguro1.setFechaInicio(LocalDate.of(2022, 1, 1));
        cliente.getSeguros().add(seguro1);

        Seguro seguro2 = new Seguro();
        seguro2.setId(2);
        seguro2.setMatricula("5678DEF");
        seguro2.setPotencia(150);
        seguro2.setCobertura(Cobertura.TODO_RIESGO);
        seguro2.setFechaInicio(LocalDate.of(2023, 1, 1));
        cliente.getSeguros().add(seguro2);

        double total = cliente.totalSeguros();
        assertEquals(250.0, total, 0.01);
        // assertEquals (250.0, total);


    }

}
